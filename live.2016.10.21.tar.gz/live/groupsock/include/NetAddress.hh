/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
**********/
// "mTunnel" multicast access service
// Copyright (c) 1996-2011 Live Networks, Inc.  All rights reserved.
// Network Addresses
// C++ header

#ifndef _NET_ADDRESS_HH
#define _NET_ADDRESS_HH

#ifndef _HASH_TABLE_HH
#include "HashTable.hh"
#endif

#ifndef _NET_COMMON_H
#include "NetCommon.h"
#endif

#ifndef _USAGE_ENVIRONMENT_HH
#include "UsageEnvironment.hh"
#endif


// Definition of a type representing a low-level network address.
// At present, this is 32-bits, for IPv4.  Later, generalize it,
// to allow for IPv6.
// SM 2011-06-08: We dont use this type anymore. Instead we use
// the NetAddress class
typedef u_int32_t netAddressBits;///XXX
class Port;

// SM 2011-06-08: The NetAddress class has been rewritten to
// support ipv6 address
// Sometimes, it is used to hold the port, even if it wasn't before
// This replaces the struct sockaddr_in or struct in_addr that
// were used everywhere in the code
class NetAddress {
    public:
    typedef union NetSockaddr {
        struct sockaddr fGeneric;
        struct sockaddr_in fIn;
        struct sockaddr_in6 fIn6;
        struct sockaddr_storage fStorage;
        } NetSockaddr;
    public:
        NetAddress();
        explicit NetAddress(const char * ip, int family = AF_INET);
        NetAddress(struct sockaddr * addr, socklen_t len);
	explicit NetAddress(u_int8_t const* data, unsigned length=4 /* if ipv4: 32 bits */);
	NetAddress(NetAddress const& orig);
        virtual ~NetAddress();

        // Note; Compare only address, not port
        NetAddress& operator=(NetAddress const& rightSide);
        Boolean operator ==( const NetAddress & a ) const;
        Boolean operator !=( const NetAddress & a ) const;

	Boolean isMulticast() const;
	Boolean isLocal() const;
	Boolean badAddress() const; // Currently synonym of isUnSpec (may change ?)
        Boolean isUnSpec() const; // This is used to check invalid address (was done before with netAddressBits(~0))
        int getFamily() const;
	const char * getAddress(char * buf, size_t bufSize) const;
        const char * getIpV6V4MappedAddress(char * buf=NULL, size_t bufSize=0) const;
        Boolean isIpV6V4Mapped() const;
	unsigned length() const;
	u_int8_t const* data() const; // always in network byte order
        struct sockaddr_storage makeSockAddr( Port port, socklen_t * len ) const;
        const struct sockaddr * getSockAddr() const {
          return &fSockAddr.fGeneric;
        }
        
        u_int16_t getPort() const;
        void setPort( u_int16_t port );
    private:
        void setAddress(const char * ip, int flags, int family);
        u_int8_t * _data() const; // return value is not const
	void clean();

        NetSockaddr fSockAddr;
};

class NetAddressList {
    public:
	NetAddressList(char const* hostname);
	NetAddressList(NetAddressList const& orig);
	NetAddressList& operator=(NetAddressList const& rightSide);
	virtual ~NetAddressList();

	unsigned numAddresses() const { return fNumAddresses; }

	NetAddress const* firstAddress() const;

	// Used to iterate through the addresses in a list:
	class Iterator {
	    public:
		Iterator(NetAddressList const& addressList);
		NetAddress const* nextAddress(); // NULL iff none
	    private:
		NetAddressList const& fAddressList;
		unsigned fNextIndex;
	};

    private:
	void assign(unsigned numAddresses, NetAddress** addressArray);
	void clean();

	friend class Iterator;
	unsigned fNumAddresses;
	NetAddress** fAddressArray;
};

typedef u_int16_t portNumBits;

class Port {
    public:
	explicit Port(portNumBits num = 0/* in host byte order */);
        Boolean operator ==( const Port & a ) const {
          return a.num() == this->num();
        }
        Boolean operator !=( const Port & a ) const {
          return a.num() != this->num();
        }

	portNumBits num() const // in network byte order
		{ return fPortNum; }
        u_int16_t port() const { return ntohs(fPortNum); }

    private:
	portNumBits fPortNum; // stored in network byte order
#ifdef IRIX
	portNumBits filler; // hack to overcome a bug in IRIX C++ compiler
#endif
};

UsageEnvironment& operator<<(UsageEnvironment& s, const Port& p);


// A generic table for looking up objects by (address1, address2, port)
class AddressPortLookupTable {
    public:
	AddressPortLookupTable();
	virtual ~AddressPortLookupTable();

	void* Add(NetAddress address1, NetAddress address2,
		  Port port, void* value);
		// Returns the old value if different, otherwise 0
	Boolean Remove(NetAddress address1, NetAddress address2,
		       Port port);
	void* Lookup(NetAddress address1, NetAddress address2,
		     Port port);
		// Returns 0 if not found
        void buildKey(NetAddress address1, NetAddress address2,
                                     Port port, uint8_t * key ) const;

	// Used to iterate through the entries in the table
	class Iterator {
	    public:
		Iterator(AddressPortLookupTable& table);
		virtual ~Iterator();

		void* next(); // NULL iff none

	    private:
		HashTable::Iterator* fIter;
	};

    private:
	friend class Iterator;
	HashTable* fTable;
};


Boolean IsMulticastAddress(NetAddress address);
struct sockaddr_storage makeSockAddr( NetAddress address, Port port, socklen_t * len );
NetAddress getSockNameFromSocket(int clientSocket);

#endif



