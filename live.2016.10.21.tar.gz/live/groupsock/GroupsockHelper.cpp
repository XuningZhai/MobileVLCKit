/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
**********/
// "mTunnel" multicast access service
// Copyright (c) 1996-2016 Live Networks, Inc.  All rights reserved.
// Helper routines to implement 'group sockets'
// Implementation

#include "GroupsockHelper.hh"

#if (defined(__WIN32__) || defined(_WIN32)) && !defined(__MINGW32__)
#include <time.h>
extern "C" int initializeWinsockIfNecessary();
#else
#include <stdarg.h>
#include <time.h>
#include <sys/time.h>
#include <fcntl.h>
#define initializeWinsockIfNecessary() 1
#endif
#if defined(__WIN32__) || defined(_WIN32) || defined(_QNX4)
#else
#include <signal.h>
#define USE_SIGNALS 1
#endif
#include <stdio.h>

#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

// By default, use INADDR_ANY for the sending and receiving interfaces:
NetAddress SendingInterfaceAddr ("", AF_UNSPEC);
NetAddress ReceivingInterfaceAddr ("", AF_UNSPEC);


static void socketErr(UsageEnvironment& env, char const* errorMsg) {
  env.setResultErrMsg(errorMsg);
}

static int reuseFlag = 1;

NoReuse::NoReuse(UsageEnvironment& env)
  : fEnv(env) {
  groupsockPriv(fEnv)->reuseFlag = 0;
}

NoReuse::~NoReuse() {
  groupsockPriv(fEnv)->reuseFlag = 1;
  reclaimGroupsockPriv(fEnv);
}


_groupsockPriv* groupsockPriv(UsageEnvironment& env) {
  if (env.groupsockPriv == NULL) { // We need to create it
    _groupsockPriv* result = new _groupsockPriv;
    result->socketTable = NULL;
    result->reuseFlag = 1; // default value => allow reuse of socket numbers
    env.groupsockPriv = result;
  }
  return (_groupsockPriv*)(env.groupsockPriv);
}

void reclaimGroupsockPriv(UsageEnvironment& env) {
  _groupsockPriv* priv = (_groupsockPriv*)(env.groupsockPriv);
  if (priv->socketTable == NULL && priv->reuseFlag == 1/*default value*/) {
    // We can delete the structure (to save space); it will get created again, if needed:
    delete priv;
    env.groupsockPriv = NULL;
  }
}

int setupDatagramSocket(UsageEnvironment& env, Port port, int family) {
  ///family=10;///XXX test mediaserver
  //std::cerr << "setupDatagramSocket - family=" << family << " port=" << port.port() << "\n";
  if (!initializeWinsockIfNecessary()) {
	socketErr(env, "Failed to initialize 'winsock': ");
	return -1;
  }

  int newSocket = socket(family, SOCK_DGRAM, 0);
  if (newSocket < 0) {
//std::cerr << "setupDatagramSocket 2 - family=" << family << " port=" << port.port() << "\n";
	socketErr(env, "unable to create datagram socket: ");
	return newSocket;
  }

  if (setsockopt(newSocket, SOL_SOCKET, SO_REUSEADDR,
		 (const char*)&reuseFlag, sizeof reuseFlag) < 0) {
	socketErr(env, "setsockopt(SO_REUSEADDR) error: ");
	closeSocket(newSocket);
	return -1;
  }

#if defined(__WIN32__) || defined(_WIN32)
  // Windoze doesn't properly handle SO_REUSEPORT or IP_MULTICAST_LOOP
#else
#ifdef SO_REUSEPORT
  if (setsockopt(newSocket, SOL_SOCKET, SO_REUSEPORT,
		 (const char*)&reuseFlag, sizeof reuseFlag) < 0) {
	socketErr(env, "setsockopt(SO_REUSEPORT) error: ");
	closeSocket(newSocket);
	return -1;
  }
#endif
#ifdef IP_MULTICAST_LOOP
  if( family == AF_INET ) {
	const u_int8_t loop = 1;
	if (setsockopt(newSocket, IPPROTO_IP, IP_MULTICAST_LOOP,
		 (const char*)&loop, sizeof loop) < 0) {
	  socketErr(env, "setsockopt(IP_MULTICAST_LOOP) error: ");
	  closeSocket(newSocket);
	  return -1;
	}
  }
#endif
#ifdef IPV6_MULTICAST_LOOP
  if( family == AF_INET6 ) {
	const uint loop = 1;
	if (setsockopt(newSocket, IPPROTO_IPV6, IPV6_MULTICAST_LOOP,
				 (const char*)&loop, sizeof loop) < 0) {
//std::cerr << "XXXX setupDatagramSocket 3 bis error=" << errno << "\n";
	  socketErr(env, "setsockopt(IPV6_MULTICAST_LOOP) error: ");
	  closeSocket(newSocket);
	  return -1;
	}
  }
#endif
#endif
  // Note: Windoze requires binding, even if the port number is 0
  NetAddress addr ("", family);
#if defined(__WIN32__) || defined(_WIN32)
#else
  if (port.num() != 0 || ReceivingInterfaceAddr.getFamily() != AF_UNSPEC) {
#endif
	//if (port.num() == 0) addr = ReceivingInterfaceAddr;
	//else 
	addr = NetAddress("", family);
	socklen_t len=0;
	struct sockaddr_storage name = addr.makeSockAddr( port, &len );
	if (bind(newSocket, (struct sockaddr*)&name, len) != 0) {
	  char tmpBuffer[100];
	  sprintf(tmpBuffer, "bind() error (port number: %d): ",
		  port.port());
	  socketErr(env, tmpBuffer);
//std::cerr << "setupDatagramSocket " << tmpBuffer << "\n";
	  closeSocket(newSocket);
	  return -1;
	}
#if defined(__WIN32__) || defined(_WIN32)
#else
  }
#endif

  // Set the sending interface for multicasts, if it's not the default:
  if (!SendingInterfaceAddr.getFamily() != AF_UNSPEC) {
	if( family == AF_INET ) {
	  struct in_addr addr;
	  memcpy( &addr.s_addr, SendingInterfaceAddr.data(), SendingInterfaceAddr.length() );
	  if (setsockopt(newSocket, IPPROTO_IP, IP_MULTICAST_IF,
		   (const char*)&addr, sizeof addr) < 0) {
		socketErr(env, "error setting outgoing multicast interface: ");
		///closeSocket(newSocket);
//std::cerr << "XXX setupDatagramSocket - error setting outgoing multicast interface \n";
		///return -1;
	  }
	} else if( family == AF_INET6 ) {
	  // IPV6_MULTICAST_IF
	  //		Set the device for outgoing multicast packets on the socket.  This is only allowed for
	  //		SOCK_DGRAM and SOCK_RAW socket.  The  argument	is	a
	  //		pointer to an interface index (see netdevice(7)) in an integer.
	}
  }

//std::cerr << "setupDatagramSocket - newSocket=" << newSocket << " family=" << family << "\n";
  return newSocket;
}



Boolean makeSocketNonBlocking(int sock) {
#if defined(__WIN32__) || defined(_WIN32)
  unsigned long arg = 1;
  return ioctlsocket(sock, FIONBIO, &arg) == 0;
#elif defined(VXWORKS)
  int arg = 1;
  return ioctl(sock, FIONBIO, (int)&arg) == 0;
#else
  int curFlags = fcntl(sock, F_GETFL, 0);
  return fcntl(sock, F_SETFL, curFlags|O_NONBLOCK) >= 0;
#endif
}

Boolean makeSocketBlocking(int sock, unsigned writeTimeoutInMilliseconds) {
  Boolean result;
#if defined(__WIN32__) || defined(_WIN32)
  unsigned long arg = 0;
  result = ioctlsocket(sock, FIONBIO, &arg) == 0;
#elif defined(VXWORKS)
  int arg = 0;
  result = ioctl(sock, FIONBIO, (int)&arg) == 0;
#else
  int curFlags = fcntl(sock, F_GETFL, 0);
  result = fcntl(sock, F_SETFL, curFlags&(~O_NONBLOCK)) >= 0;
#endif

  if (writeTimeoutInMilliseconds > 0) {
#ifdef SO_SNDTIMEO
    struct timeval tv;
    tv.tv_sec = writeTimeoutInMilliseconds/1000;
    tv.tv_usec = (writeTimeoutInMilliseconds%1000)*1000;
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv, sizeof tv);
#endif
  }

  return result;
}

int setupStreamSocket(UsageEnvironment& env,
                      Port port, int family, Boolean makeNonBlocking) {
  //std::cerr << "setupStreamSocket JJJ - port=" << port.port() << " - family=" << family << "\n";
  if (!initializeWinsockIfNecessary()) {
    socketErr(env, "Failed to initialize 'winsock': ");
    return -1;
  }

  int newSocket = socket(family, SOCK_STREAM, 0);
  if (newSocket < 0) {
    socketErr(env, "unable to create stream socket: ");
    return newSocket;
  }

  if (setsockopt(newSocket, SOL_SOCKET, SO_REUSEADDR,
		 (const char*)&reuseFlag, sizeof reuseFlag) < 0) {
    socketErr(env, "setsockopt(SO_REUSEADDR) error: ");
    closeSocket(newSocket);
    return -1;
  }

  // SO_REUSEPORT doesn't really make sense for TCP sockets, so we
  // normally don't set them.  However, if you really want to do this
  // #define REUSE_FOR_TCP
#ifdef REUSE_FOR_TCP
#if defined(__WIN32__) || defined(_WIN32)
  // Windoze doesn't properly handle SO_REUSEPORT
#else
#ifdef SO_REUSEPORT
  if (setsockopt(newSocket, SOL_SOCKET, SO_REUSEPORT,
		 (const char*)&reuseFlag, sizeof reuseFlag) < 0) {
    socketErr(env, "setsockopt(SO_REUSEPORT) error: ");
    closeSocket(newSocket);
    return -1;
  }
#endif
#endif
#endif

  // Note: Windoze requires binding, even if the port number is 0
#if defined(__WIN32__) || defined(_WIN32)
#else  
  if (port.num() != 0 || ReceivingInterfaceAddr.getFamily() != AF_UNSPEC) {
#endif
    NetAddress addr;
    //if (port.num() == 0) addr = ReceivingInterfaceAddr;
    //else 
    addr = NetAddress("", family);
    socklen_t len=0;
    struct sockaddr_storage name = addr.makeSockAddr( port, &len );
//std::cerr << "setupStreamSocket 3 bis _ port=" << port.port() << " family="  << family << "\n";
    if (bind(newSocket, (struct sockaddr*)&name, len) != 0) {
      char tmpBuffer[100];
      sprintf(tmpBuffer, "bind() error (port number: %d): ",
	      port.port());
      socketErr(env, tmpBuffer);
      closeSocket(newSocket);
	  
//std::cerr << "setupStreamSocket 4" << tmpBuffer << "\n";
      return -1;
    }
#if defined(__WIN32__) || defined(_WIN32)
#else
  }
#endif
  if (makeNonBlocking) {
    if (!makeSocketNonBlocking(newSocket)) {
      socketErr(env, "failed to make non-blocking: ");
      closeSocket(newSocket);
      return -1;
    }
  }

//std::cerr << "setupStreamSocket - newSocket=" << newSocket << "\n";
  return newSocket;
}


int readSocket(UsageEnvironment& env,
	       int socket, unsigned char* buffer, unsigned bufferSize,
	       NetAddress& fromAddress) {
  struct sockaddr_storage fa;
  SOCKLEN_T addressSize = sizeof fa;
  int bytesRead = recvfrom(socket, (char*)buffer, bufferSize, 0,
			   (struct sockaddr*)&fa,
			   &addressSize);
//std::cerr << "readSocket socket=" << socket << " - bytesRead=" << bytesRead << "\n";
  fromAddress = NetAddress( (struct sockaddr*)&fa, addressSize );
  if (bytesRead < 0) {
    //##### HACK to work around bugs in Linux and Windows:
    int err = env.getErrno();
    if (err == 111 /*ECONNREFUSED (Linux)*/
#if defined(__WIN32__) || defined(_WIN32)
	// What a piece of crap Windows is.  Sometimes
	// recvfrom() returns -1, but with an 'errno' of 0.
	// This appears not to be a real error; just treat
	// it as if it were a read of zero bytes, and hope
	// we don't have to do anything else to 'reset'
	// this alleged error:
	|| err == 0 || err == EWOULDBLOCK
#else
	|| err == EAGAIN
#endif
	|| err == 113 /*EHOSTUNREACH (Linux)*/) { // Why does Linux return this for datagram sock?
      fromAddress = NetAddress( "", fa.ss_family ); ///.sin_addr.s_addr = 0;
      return 0;
    }
    //##### END HACK
    socketErr(env, "recvfrom() error: ");
  }

  return bytesRead;
}

Boolean writeSocket(UsageEnvironment& env,
		    int socket, NetAddress address, Port port,
		    u_int8_t ttlArg,
		    unsigned char* buffer, unsigned bufferSize) {
  int family = address.getFamily();
	do {
		if (ttlArg != 0) {
			// Before sending, set the socket's TTL:
#if defined(__WIN32__) || defined(_WIN32)
#define TTL_TYPE int
#else
#define TTL_TYPE u_int8_t
#endif
                    if( family == AF_INET ) {
			TTL_TYPE ttl = (TTL_TYPE)ttlArg;
			if (setsockopt(socket, IPPROTO_IP, IP_MULTICAST_TTL,
				       (const char*)&ttl, sizeof ttl) < 0) {
				socketErr(env, "setsockopt(IP_MULTICAST_TTL) error: ");
				break;
			}
                    } else if( family == AF_INET6 ) {
                        TTL_TYPE ttl = (TTL_TYPE)ttlArg;
                        if (setsockopt(socket, IPPROTO_IPV6, IPV6_MULTICAST_HOPS,
                                       (const char*)&ttl, sizeof ttl) < 0) {
                                socketErr(env, "setsockopt(IPV6_MULTICAST_HOPS) error: ");
                                break;
                        }
                    }
		}
                socklen_t len;
                struct sockaddr_storage da = address.makeSockAddr(port, &len);
		int bytesSent = sendto(socket, (char*)buffer, bufferSize, MSG_NOSIGNAL,
			               (struct sockaddr*)&da, len);
		if (bytesSent != (int)bufferSize) {
			char tmpBuf[100];
			sprintf(tmpBuf, "writeSocket(%d), sendTo() error: wrote %d bytes instead of %u: ", socket,
                                bytesSent, bufferSize);
			socketErr(env, tmpBuf);
			break;
		}

		return True;
	} while (0);

	return False;
}


void ignoreSigPipeOnSocket(int socketNum) {
  #ifdef USE_SIGNALS
  #ifdef SO_NOSIGPIPE
  int set_option = 1;
  setsockopt(socketNum, SOL_SOCKET, SO_NOSIGPIPE, &set_option, sizeof set_option);
  #else
  signal(SIGPIPE, SIG_IGN);
  #endif
  #endif
}

static unsigned getBufferSize(UsageEnvironment& env, int bufOptName,
			      int socket) {
  unsigned curSize;
  SOCKLEN_T sizeSize = sizeof curSize;
  if (getsockopt(socket, SOL_SOCKET, bufOptName,
		 (char*)&curSize, &sizeSize) < 0) {
    socketErr(env, "getBufferSize() error: ");
    return 0;
  }

  return curSize;
}
unsigned getSendBufferSize(UsageEnvironment& env, int socket) {
  return getBufferSize(env, SO_SNDBUF, socket);
}
unsigned getReceiveBufferSize(UsageEnvironment& env, int socket) {
  return getBufferSize(env, SO_RCVBUF, socket);
}

static unsigned setBufferTo(UsageEnvironment& env, int bufOptName,
			    int socket, unsigned requestedSize) {
  SOCKLEN_T sizeSize = sizeof requestedSize;
  setsockopt(socket, SOL_SOCKET, bufOptName, (char*)&requestedSize, sizeSize);

  // Get and return the actual, resulting buffer size:
  return getBufferSize(env, bufOptName, socket);
}
unsigned setSendBufferTo(UsageEnvironment& env,
			 int socket, unsigned requestedSize) {
	return setBufferTo(env, SO_SNDBUF, socket, requestedSize);
}
unsigned setReceiveBufferTo(UsageEnvironment& env,
			    int socket, unsigned requestedSize) {
	return setBufferTo(env, SO_RCVBUF, socket, requestedSize);
}

static unsigned increaseBufferTo(UsageEnvironment& env, int bufOptName,
				 int socket, unsigned requestedSize) {
  // First, get the current buffer size.  If it's already at least
  // as big as what we're requesting, do nothing.
  unsigned curSize = getBufferSize(env, bufOptName, socket);

  // Next, try to increase the buffer to the requested size,
  // or to some smaller size, if that's not possible:
  while (requestedSize > curSize) {
    SOCKLEN_T sizeSize = sizeof requestedSize;
    if (setsockopt(socket, SOL_SOCKET, bufOptName,
		   (char*)&requestedSize, sizeSize) >= 0) {
      // success
      return requestedSize;
    }
    requestedSize = (requestedSize+curSize)/2;
  }

  return getBufferSize(env, bufOptName, socket);
}
unsigned increaseSendBufferTo(UsageEnvironment& env,
			      int socket, unsigned requestedSize) {
  return increaseBufferTo(env, SO_SNDBUF, socket, requestedSize);
}
unsigned increaseReceiveBufferTo(UsageEnvironment& env,
				 int socket, unsigned requestedSize) {
  return increaseBufferTo(env, SO_RCVBUF, socket, requestedSize);
}

Boolean socketJoinGroup(UsageEnvironment& env, int socket,
			NetAddress groupAddress){
//std::cerr << "socketJoinGroup - socket=" << socket << "\n";
  if (!groupAddress.isMulticast()) return True; // ignore this case
  if( groupAddress.getFamily() == AF_INET ) {
    struct ip_mreq imr;
    struct sockaddr_in * in = (struct sockaddr_in *)groupAddress.getSockAddr();
    imr.imr_multiaddr.s_addr = in->sin_addr.s_addr;
    if( ReceivingInterfaceAddr.getFamily() == AF_INET ) {
      in = (struct sockaddr_in *)ReceivingInterfaceAddr.getSockAddr();
      imr.imr_interface.s_addr = in->sin_addr.s_addr;
    } else {
       imr.imr_interface.s_addr = INADDR_ANY;
    }
    if (setsockopt(socket, IPPROTO_IP, IP_ADD_MEMBERSHIP,
		 (const char*)&imr, sizeof (struct ip_mreq)) < 0) {
#if defined(__WIN32__) || defined(_WIN32)
      if (env.getErrno() != 0) {
        // That piece-of-shit toy operating system (Windows) sometimes lies
        // about setsockopt() failing!
#endif
        socketErr(env, "setsockopt(IP_ADD_MEMBERSHIP) error: ");
        return False;
#if defined(__WIN32__) || defined(_WIN32)
      }
#endif
    }
  } else if( groupAddress.getFamily() == AF_INET6 ) {
    struct ipv6_mreq imr;
    imr.ipv6mr_interface = 0; ///XXX
    const struct sockaddr_in6 * in6 = (const struct sockaddr_in6 *)groupAddress.getSockAddr();
    imr.ipv6mr_multiaddr = in6->sin6_addr;
    if (setsockopt(socket, IPPROTO_IPV6, IPV6_JOIN_GROUP,
                 (const char*)&imr, sizeof (struct ip_mreq)) < 0) {
#if defined(__WIN32__) || defined(_WIN32)
      if (env.getErrno() != 0) {
        // That piece-of-shit toy operating system (Windows) sometimes lies
        // about setsockopt() failing!
#endif
        socketErr(env, "setsockopt(IPV6_JOIN_GROUP) error: ");
        return False;
#if defined(__WIN32__) || defined(_WIN32)
      }
#endif
    }
  } else {
    return false;
  }

  return True;
}


Boolean socketLeaveGroup(UsageEnvironment&, int socket,
			 NetAddress groupAddress) {
//std::cerr << "socketLeaveGroup - socket=" << socket << "\n";
  if (!groupAddress.isMulticast()) return True; // ignore this case

  if( groupAddress.getFamily() == AF_INET ) {
    struct ip_mreq imr;
    struct sockaddr_in * in = (struct sockaddr_in *)groupAddress.getSockAddr();
    imr.imr_multiaddr.s_addr = in->sin_addr.s_addr;
    if( ReceivingInterfaceAddr.getFamily() == AF_INET ) {
      in = (struct sockaddr_in *)ReceivingInterfaceAddr.getSockAddr();
      imr.imr_interface.s_addr = in->sin_addr.s_addr;
    } else {
       imr.imr_interface.s_addr = INADDR_ANY;
    }
    if (setsockopt(socket, IPPROTO_IP, IP_DROP_MEMBERSHIP,
		 (const char*)&imr, sizeof (struct ip_mreq)) < 0) {
      return False;
    }
  } else if( groupAddress.getFamily() == AF_INET6 ) {
    struct ipv6_mreq imr;
    imr.ipv6mr_interface = 0; ///XXX
    const struct sockaddr_in6 * in6 = (const struct sockaddr_in6 *)groupAddress.getSockAddr();
    imr.ipv6mr_multiaddr = in6->sin6_addr;
    if (setsockopt(socket, IPPROTO_IPV6, IPV6_LEAVE_GROUP,
                 (const char*)&imr, sizeof (struct ip_mreq)) < 0) {
      return False;
    }
  } else {
    return False;
  }

  return True;
}


// The source-specific join/leave operations require special setsockopt()
// commands, and a special structure (ip_mreq_source).  If the include files
// didn't define these, we do so here:
#if !defined(IP_ADD_SOURCE_MEMBERSHIP)
struct ip_mreq_source {
  struct  in_addr imr_multiaddr;  /* IP multicast address of group */
  struct  in_addr imr_sourceaddr; /* IP address of source */
  struct  in_addr imr_interface;  /* local IP address of interface */
};
#endif

#ifndef IP_ADD_SOURCE_MEMBERSHIP

#ifdef LINUX
#define IP_ADD_SOURCE_MEMBERSHIP   39
#define IP_DROP_SOURCE_MEMBERSHIP 40
#else
#define IP_ADD_SOURCE_MEMBERSHIP   25
#define IP_DROP_SOURCE_MEMBERSHIP 26
#endif

#endif

Boolean socketJoinGroupSSM(UsageEnvironment& env, int socket,
			   NetAddress groupAddress,
			   NetAddress sourceFilterAddr) {
//std::cerr << "socketJoinGroupSSM socket=" << socket << "\n";
  if (!groupAddress.isMulticast()) {
    return True; // ignore this case
  }

  if( groupAddress.getFamily() == AF_INET ) {
    struct ip_mreq_source imr;
    const struct sockaddr_in * in = (struct sockaddr_in *)groupAddress.getSockAddr();
    imr.imr_multiaddr.s_addr = in->sin_addr.s_addr;
    in = (struct sockaddr_in *)sourceFilterAddr.getSockAddr();
    imr.imr_sourceaddr.s_addr = in->sin_addr.s_addr;
    in = (struct sockaddr_in *)ReceivingInterfaceAddr.getSockAddr();
    imr.imr_interface.s_addr = in->sin_addr.s_addr;
    if (setsockopt(socket, IPPROTO_IP, IP_ADD_SOURCE_MEMBERSHIP,
		 (const char*)&imr, sizeof (struct ip_mreq_source)) < 0) {
      socketErr(env, "setsockopt(IP_ADD_SOURCE_MEMBERSHIP) error: ");
      return False;
    }
  } else if( groupAddress.getFamily() == AF_INET6 ) {
    ///XXX TODO
    return false;
  } else {
    return false;
  }

  return True;
}

Boolean socketLeaveGroupSSM(UsageEnvironment& /*env*/, int socket,
			    NetAddress groupAddress,
			    NetAddress sourceFilterAddr) {
//std::cerr << "socketLeaveGroupSSM socket=" << socket << "\n";
  if (!groupAddress.isMulticast()) {
    return True; // ignore this case
  }

  if( groupAddress.getFamily() == AF_INET ) {
    struct ip_mreq_source imr;
    const struct sockaddr_in * in = (struct sockaddr_in *)groupAddress.getSockAddr();
    imr.imr_multiaddr.s_addr = in->sin_addr.s_addr;
    in = (struct sockaddr_in *)sourceFilterAddr.getSockAddr();
    imr.imr_sourceaddr.s_addr = in->sin_addr.s_addr;
    in = (struct sockaddr_in *)ReceivingInterfaceAddr.getSockAddr();
    imr.imr_interface.s_addr = in->sin_addr.s_addr;
    if (setsockopt(socket, IPPROTO_IP, IP_DROP_SOURCE_MEMBERSHIP,
  		 (const char*)&imr, sizeof (struct ip_mreq_source)) < 0) {
      return False;
    }
  } else if( groupAddress.getFamily() == AF_INET6 ) {
    ///XXX TODO
    return false;
  } else {
    return false;
  }

  return True;
}


static Boolean getSourcePort0(int socket, NetAddress & sockname) {
  struct sockaddr_storage test; memset( &test, 0, sizeof(test) );
  SOCKLEN_T len = sizeof test;
  if (getsockname(socket, (struct sockaddr*)&test, &len) < 0) {
//std::cerr << "====> error getsockname socket="<<socket<< " errno=" << errno << "\n";
    return False;
  }
//std::cerr << "====> ok getsockname socket="<<socket<< "\n";
  sockname = NetAddress((struct sockaddr*)&test, len);
  return True;
}

Boolean getSourcePort(UsageEnvironment& env, int socket, Port& port) {
  port = Port(0);
  NetAddress sockname;
  if (!getSourcePort0(socket, sockname) || sockname.getPort() == 0) {
    // Hack - call bind(), then try again:
    NetAddress none ( "", sockname.getFamily() );
    socklen_t len;
    struct sockaddr_storage name = none.makeSockAddr(Port(0), &len);
    bind(socket, (struct sockaddr*)&name, len);

    if (!getSourcePort0(socket, sockname) || sockname.getPort() == 0) {
      socketErr(env, "getsockname() error: ");
//std::cerr << "====> error getsockname socket="<<socket<< "\n";
      return False;
    }
  }

  port = Port(sockname.getPort());
  return True;
}


static Boolean badAddressForUs(netAddressBits addr) {
  // Check for some possible erroneous addresses:
  netAddressBits nAddr = htonl(addr);
  return (nAddr == 0x7F000001 /* 127.0.0.1 */
	  || nAddr == 0
	  || nAddr == (netAddressBits)(~0));
}

Boolean loopbackWorks = 1;

NetAddress ourIPAddress(UsageEnvironment& env, int family) {
  //std::cerr << "XXX NetAddress ourIPAddress - family=" << family << "\n";
  ///XXX total rewrite
#if 0
  static netAddressBits ourAddress = 0;
  int sock = -1;
  struct in_addr testAddr;

  if (ourAddress == 0) {
    // We need to find our source address
    struct sockaddr_in fromAddr;
    fromAddr.sin_addr.s_addr = 0;

    // Get our address by sending a (0-TTL) multicast packet,
    // receiving it, and looking at the source address used.
    // (This is kinda bogus, but it provides the best guarantee
    // that other nodes will think our address is the same as we do.)
    do {
      loopbackWorks = 0; // until we learn otherwise

      testAddr.s_addr = our_inet_addr("228.67.43.91"); // arbitrary
      Port testPort(15947); // ditto

      sock = setupDatagramSocket(env, testPort);
      if (sock < 0) break;

      if (!socketJoinGroup(env, sock, testAddr.s_addr)) break;

      unsigned char testString[] = "hostIdTest";
      unsigned testStringLength = sizeof testString;

      if (!writeSocket(env, sock, testAddr, testPort, 0,
		       testString, testStringLength)) break;

      // Block until the socket is readable (with a 5-second timeout):
      fd_set rd_set;
      FD_ZERO(&rd_set);
      FD_SET((unsigned)sock, &rd_set);
      const unsigned numFds = sock+1;
      struct timeval timeout;
      timeout.tv_sec = 5;
      timeout.tv_usec = 0;
      int result = select(numFds, &rd_set, NULL, NULL, &timeout);
      if (result <= 0) break;

      unsigned char readBuffer[20];
      int bytesRead = readSocket(env, sock,
				 readBuffer, sizeof readBuffer,
				 fromAddr);
      if (bytesRead != (int)testStringLength
	  || strncmp((char*)readBuffer, (char*)testString, testStringLength) != 0) {
	break;
      }

      loopbackWorks = 1;
    } while (0);

    if (!loopbackWorks) do {
      // We couldn't find our address using multicast loopback
      // so try instead to look it up directly.
      char hostname[100];
      hostname[0] = '\0';
      gethostname(hostname, sizeof hostname);
      if (hostname[0] == '\0') {
	env.setResultErrMsg("initial gethostname() failed");
	break;
      }

#if defined(VXWORKS)
#include <hostLib.h>
      if (ERROR == (ourAddress = hostGetByName( hostname ))) break;
#else
      struct hostent* hstent
	= (struct hostent*)gethostbyname(hostname);
      if (hstent == NULL || hstent->h_length != 4) {
	env.setResultErrMsg("initial gethostbyname() failed");
	break;
      }
      // Take the first address that's not bad
      // (This code, like many others, won't handle IPv6)
      netAddressBits addr = 0;
      for (unsigned i = 0; ; ++i) {
	char* addrPtr = hstent->h_addr_list[i];
	if (addrPtr == NULL) break;

	netAddressBits a = *(netAddressBits*)addrPtr;
	if (!badAddress(a)) {
	  addr = a;
	  break;
	}
      }
      if (addr != 0) {
	fromAddr.sin_addr.s_addr = addr;
      } else {
	env.setResultMsg("no address");
	break;
      }
    } while (0);

    // Make sure we have a good address:
    netAddressBits from = fromAddr.sin_addr.s_addr;
    if (badAddress(from)) {
      char tmp[100];
      sprintf(tmp,
	      "This computer has an invalid IP address: 0x%x",
	      (netAddressBits)(ntohl(from)));
      env.setResultMsg(tmp);
      from = 0;
    }

    ourAddress = from;
#endif

    if (sock >= 0) {
      socketLeaveGroup(env, sock, testAddr.s_addr);
      closeSocket(sock);
    }

    // Use our newly-discovered IP address, and the current time,
    // to initialize the random number generator's seed:
    struct timeval timeNow;
    gettimeofday(&timeNow, NULL);
    unsigned seed = ourAddress^timeNow.tv_sec^timeNow.tv_usec;
    our_srandom(seed);
  }
  return ourAddress;
#endif
  /// XXX : KISS
  NetAddress ip ("", family);
  if( family == AF_INET ) {
    ip = NetAddress( getenv("IP"), AF_INET);
  } else if( family == AF_INET6 ) {    
    ip = NetAddress( getenv("IP6"), AF_INET6);
  }

  
  return ip;
}


NetAddress chooseRandomIPv4SSMAddress(UsageEnvironment& env) {
  ///XXX
  //std::cerr << "XXXXXXXX chooseRandomIPv4SSMAddress\n";
#if 0
  // First, a hack to ensure that our random number generator is seeded:
  (void) ourIPAddress(env);

  // Choose a random address in the range [232.0.1.0, 232.255.255.255)
  // i.e., [0xE8000100, 0xE8FFFFFF)
  netAddressBits const first = 0xE8000100, lastPlus1 = 0xE8FFFFFF;
  netAddressBits const range = lastPlus1 - first;

  return htonl(first + ((netAddressBits)our_random())%range);
#endif
  NetAddress todo;
  return todo;
}


char const* timestampString() {
  struct timeval tvNow;
  gettimeofday(&tvNow, NULL);

#if !defined(_WIN32_WCE)
  static char timeString[9]; // holds hh:mm:ss plus trailing '\0'

  time_t tvNow_t = tvNow.tv_sec;
  char const* ctimeResult = ctime(&tvNow_t);
  if (ctimeResult == NULL) {
    sprintf(timeString, "??:??:??");
  } else {
    char const* from = &ctimeResult[11];
    int i;
    for (i = 0; i < 8; ++i) {
      timeString[i] = from[i];
    }
    timeString[i] = '\0';
  }
#else
  // WinCE apparently doesn't have "ctime()", so instead, construct
  // a timestamp string just using the integer and fractional parts
  // of "tvNow":
  static char timeString[50];
  sprintf(timeString, "%lu.%06ld", tvNow.tv_sec, tvNow.tv_usec);
#endif

  return (char const*)&timeString;
}

#if (defined(__WIN32__) || defined(_WIN32)) && !defined(__MINGW32__)
// For Windoze, we need to implement our own gettimeofday()

// used to make sure that static variables in gettimeofday() aren't initialized simultaneously by multiple threads
static LONG initializeLock_gettimeofday = 0;  

#if !defined(_WIN32_WCE)
#include <sys/timeb.h>
#endif

int gettimeofday(struct timeval* tp, int* /*tz*/) {
  static LARGE_INTEGER tickFrequency, epochOffset;

  static Boolean isInitialized = False;

  LARGE_INTEGER tickNow;

#if !defined(_WIN32_WCE)
  QueryPerformanceCounter(&tickNow);
#else
  tickNow.QuadPart = GetTickCount();
#endif
 
  if (!isInitialized) {
    if(1 == InterlockedIncrement(&initializeLock_gettimeofday)) {
#if !defined(_WIN32_WCE)
      // For our first call, use "ftime()", so that we get a time with a proper epoch.
      // For subsequent calls, use "QueryPerformanceCount()", because it's more fine-grain.
      struct timeb tb;
      ftime(&tb);
      tp->tv_sec = tb.time;
      tp->tv_usec = 1000*tb.millitm;

      // Also get our counter frequency:
      QueryPerformanceFrequency(&tickFrequency);
#else
      /* FILETIME of Jan 1 1970 00:00:00. */
      const LONGLONG epoch = 116444736000000000LL;
      FILETIME fileTime;
      LARGE_INTEGER time;
      GetSystemTimeAsFileTime(&fileTime);

      time.HighPart = fileTime.dwHighDateTime;
      time.LowPart = fileTime.dwLowDateTime;

      // convert to from 100ns time to unix timestamp in seconds, 1000*1000*10
      tp->tv_sec = (long)((time.QuadPart - epoch) / 10000000L);

      /*
        GetSystemTimeAsFileTime has just a seconds resolution,
        thats why wince-version of gettimeofday is not 100% accurate, usec accuracy would be calculated like this:
        // convert 100 nanoseconds to usec
        tp->tv_usec= (long)((time.QuadPart - epoch)%10000000L) / 10L;
      */
      tp->tv_usec = 0;

      // resolution of GetTickCounter() is always milliseconds
      tickFrequency.QuadPart = 1000;
#endif     
      // compute an offset to add to subsequent counter times, so we get a proper epoch:
      epochOffset.QuadPart
          = tp->tv_sec * tickFrequency.QuadPart + (tp->tv_usec * tickFrequency.QuadPart) / 1000000L - tickNow.QuadPart;
      
      // next caller can use ticks for time calculation
      isInitialized = True; 
      return 0;
    } else {
        InterlockedDecrement(&initializeLock_gettimeofday);
        // wait until first caller has initialized static values
        while(!isInitialized){
          Sleep(1);
        }
    }
  }

  // adjust our tick count so that we get a proper epoch:
  tickNow.QuadPart += epochOffset.QuadPart;

  tp->tv_sec =  (long)(tickNow.QuadPart / tickFrequency.QuadPart);
  tp->tv_usec = (long)(((tickNow.QuadPart % tickFrequency.QuadPart) * 1000000L) / tickFrequency.QuadPart);

  return 0;
}
#endif
