/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
**********/
// "mTunnel" multicast access service
// Copyright (c) 1996-2011 Live Networks, Inc.  All rights reserved.
// Network Addresses
// Implementation

#include "NetAddress.hh"
#include "GroupsockHelper.hh"

#include <stddef.h>
#include <stdio.h>
#include <iostream>
#if defined(__WIN32__) || defined(_WIN32)
#else
#ifndef INADDR_NONE
#define INADDR_NONE 0xFFFFFFFF
#endif
#endif

#define IOS
#ifdef IOS
#define s6_addr32 __u6_addr.__u6_addr32
#endif


////////// NetAddress //////////
NetAddress::NetAddress() {
  this->clean();
}

NetAddress::NetAddress(struct sockaddr * addr, socklen_t len) {
    memcpy( &fSockAddr.fGeneric, addr, len );
}

NetAddress::NetAddress(const char * ipOrName, int family) {

  if(ipOrName && strchr(ipOrName, ':'))
  {
  	family =  AF_INET6;
  }
  
  this->clean();
  this->setAddress(ipOrName, /*AI_NUMERICHOST*/0, family) ;
}

NetAddress::NetAddress(u_int8_t const* data, unsigned length) {
  /// XXX this constructor has been kept because some class build
  /// fake NetAddress objects using socket handles as data, and 4 for the length
  this->clean();
  
  int family = AF_UNSPEC;
  char ip[256];  char * p = ip;
  if( length == 4 ) {
    family = AF_INET;
    for( size_t i = 0; i < length; i ++ ) {
      if( i != 0 ) {
        p += sprintf( p, "." );
      }
      p += sprintf( ip, "%1d", data[i] );
    }
  } else if( length == 16 ) {
    family = AF_INET6;
    for( size_t i = 0; i < length%2; i ++ ) {
      if( i != 0 ) {
        p += sprintf( p, ":" );
      }
      p += sprintf( ip, "%1x", data[i] );
      p += sprintf( ip, "%1x", data[i+1] );
    }
  } else {
    length = 0;
  }
  if( length ) {
    this->setAddress(ip, AI_NUMERICHOST, family);
  }
}

NetAddress::NetAddress(NetAddress const& orig) {
  this->fSockAddr = orig.fSockAddr;
}

NetAddress& NetAddress::operator=(NetAddress const& rightSide) {
  if (&rightSide != this) {
    clean();
    this->fSockAddr = rightSide.fSockAddr;
  }
  return *this;
}

Boolean NetAddress::operator ==( const NetAddress & a ) const {
  return this->getFamily() == a.getFamily() && memcmp( this->data(), a.data(), this->length() ) == 0;
}

Boolean NetAddress::operator !=( const NetAddress & a ) const {
  return ! this->operator==(a);
}

NetAddress::~NetAddress() {
  clean();
}

Boolean NetAddress::isMulticast() const {
  Boolean res = false;
  if( this->getFamily() == AF_INET ) {
    uint8_t addr_elem;
    addr_elem = (ntohl(fSockAddr.fIn.sin_addr.s_addr) >> 24) & 0xff;
    res = ((addr_elem >= 224) && (addr_elem <= 239));
  } else if( this->getFamily() == AF_INET6 ) {
    res = (IN6_IS_ADDR_MULTICAST(&fSockAddr.fIn6.sin6_addr));
  }
  return res;
}

Boolean NetAddress::isLocal() const {
  Boolean res = false;
  if( this->getFamily() == AF_INET ) {
    res = (fSockAddr.fIn.sin_addr.s_addr == htonl(0x7f000001));
  } else if( this->getFamily() == AF_INET6 ) {
    res = (IN6_IS_ADDR_LOOPBACK(&fSockAddr.fIn6.sin6_addr)) ||
          (IN6_IS_ADDR_V4MAPPED(&fSockAddr.fIn6.sin6_addr) && fSockAddr.fIn6.sin6_addr.s6_addr32[3] == htonl(0x7f000001));
  }
  return res;
}

Boolean NetAddress::badAddress() const {
  return this->isUnSpec();
}

Boolean NetAddress::isUnSpec() const {
  if( this->getFamily() == AF_UNSPEC ) return true;
  return false;
}

void NetAddress::setAddress(const char * ip, int flags, int family) {
  struct addrinfo hints;
  struct addrinfo *result;
  int s;
  if( ip == NULL || ip[0] == 0 ) {
    if( family == AF_INET ) {
      ip = "0.0.0.0";
    } else if( family == AF_INET6 ) {
      ip = "::";
    }
	else
		return;
  }

  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = family;
  hints.ai_flags = flags;
  hints.ai_socktype = SOCK_DGRAM; // Restrict getaddrinfo() result
  hints.ai_protocol = 0;          // Any protocol
  hints.ai_canonname = NULL;
  hints.ai_addr = NULL;
  hints.ai_next = NULL;

  s = ::getaddrinfo( ip, NULL, &hints, &result);
  if( s == 0 ) {
///std::cerr << "NetAddress::setAddress OK\n";
    // Get first address
    memcpy( &fSockAddr, result->ai_addr, result->ai_addrlen );
    ::freeaddrinfo(result);
  } else {
//std::cerr << "XXX NetAddress::setAddress ERROR\n";
  }
}

const char * NetAddress::getAddress(char * buf, size_t bufSize) const {
  const char *res=NULL;
  buf[0] = 0;
  if( bufSize != 0 ) {
    res = inet_ntop(this->getFamily(), this->data(), buf, bufSize);
    if(res == NULL) {
      res = buf; //Avoid returning NULL when user gives us a valid buffer
    }
  }
  return res;
}

const char * NetAddress::getIpV6V4MappedAddress(char * buf, size_t bufSize) const {
  const char *res=NULL;
  if( this->getFamily() == AF_INET6 ) {
      if( this->isIpV6V4Mapped() ) {
        res = buf;
        snprintf( buf, bufSize, "%1d.%1d.%1d.%1d", 
                        (int)fSockAddr.fIn6.sin6_addr.s6_addr[12],
                        (int)fSockAddr.fIn6.sin6_addr.s6_addr[13],
                        (int)fSockAddr.fIn6.sin6_addr.s6_addr[14],
                        (int)fSockAddr.fIn6.sin6_addr.s6_addr[15] );

      }
  }
  return res;
}

Boolean NetAddress::isIpV6V4Mapped() const {
  Boolean ret = false;
  if( this->getFamily() == AF_INET6 ) {
    if( IN6_IS_ADDR_V4MAPPED(&fSockAddr.fIn6.sin6_addr) || IN6_IS_ADDR_V4COMPAT(&fSockAddr.fIn6.sin6_addr) ) {
      ret = true;
    }
  }
  return ret;
}


void NetAddress::clean() {
    ::memset(&fSockAddr, 0, sizeof(fSockAddr));
    fSockAddr.fGeneric.sa_family = PF_UNSPEC;
}

unsigned NetAddress::length() const {
  unsigned res = 0;;
  if( this->getFamily() == AF_INET ) {
    res = 4;
  } else if( this->getFamily() == AF_INET6 ) {
    res = 16;
  }
  return res;
}

u_int8_t * NetAddress::_data() const {
  u_int8_t * addr = NULL;;
  if( this->getFamily() == AF_INET ) {
    addr = (u_int8_t *)&fSockAddr.fIn.sin_addr;
  } else if( this->getFamily() == AF_INET6 ) {
    addr = (u_int8_t *)&fSockAddr.fIn6.sin6_addr;
  }
  return addr;
}

u_int8_t const * NetAddress::data() const {
  return this->_data();
}

int NetAddress::getFamily() const  {
  return fSockAddr.fGeneric.sa_family;
}

struct sockaddr_storage NetAddress::makeSockAddr( Port port, socklen_t * len ) const {
  NetSockaddr res = fSockAddr;
  if( this->getFamily() == AF_INET ) {
    res.fIn.sin_port = port.num();
	*len = sizeof(res.fIn);
  } else if( this->getFamily() == AF_INET6 ) {
    res.fIn6.sin6_port = port.num();
	*len = sizeof(res.fIn6);
  } else {
  	*len = 0;
  }
  
  return res.fStorage;
}

u_int16_t NetAddress::getPort() const {
  u_int16_t port=0;
  if( this->getFamily() == AF_INET ) {
    port = ntohs(fSockAddr.fIn.sin_port);
  } else if( this->getFamily() == AF_INET6 ) {
    port = ntohs(fSockAddr.fIn6.sin6_port);
  }
  return port;
}

void NetAddress::setPort( u_int16_t port ) {
  if( this->getFamily() == AF_INET ) {
    fSockAddr.fIn.sin_port = htons(port);
  } else if( this->getFamily() == AF_INET6 ) {
    fSockAddr.fIn6.sin6_port = htons(port);
  }
}


////////// NetAddressList //////////

NetAddressList::NetAddressList(char const* hostname)
  : fNumAddresses(0), fAddressArray(NULL) {

    /// XXX: get only first host
    NetAddress addr((char*)hostname);
    if (!addr.isUnSpec()) {
      fNumAddresses = 1;
      fAddressArray = new NetAddress*[fNumAddresses];
      if (fAddressArray == NULL) return;
      fAddressArray[0] = new NetAddress(addr);
      return;
    }
}

NetAddressList::NetAddressList(NetAddressList const& orig) {
  assign(orig.numAddresses(), orig.fAddressArray);
}

NetAddressList& NetAddressList::operator=(NetAddressList const& rightSide) {
  if (&rightSide != this) {
    clean();
    assign(rightSide.numAddresses(), rightSide.fAddressArray);
  }
  return *this;
}

NetAddressList::~NetAddressList() {
  clean();
}


void NetAddressList::assign(unsigned numAddresses, NetAddress** addressArray) {
  fAddressArray = new NetAddress*[numAddresses];
  if (fAddressArray == NULL) {
    fNumAddresses = 0;
    return;
  }

  for (unsigned i = 0; i < numAddresses; ++i) {
    fAddressArray[i] = new NetAddress(*addressArray[i]);
  }
  fNumAddresses = numAddresses;
}

void NetAddressList::clean() {
  while (fNumAddresses-- > 0) {
    delete fAddressArray[fNumAddresses];
  }
  delete[] fAddressArray; fAddressArray = NULL;
}

NetAddress const* NetAddressList::firstAddress() const {
  if (fNumAddresses == 0) {
    std::cerr << "XXXX NetAddressList::firstAddress() return NULL\n";
    return NULL;
  }

  return fAddressArray[0];
}

////////// NetAddressList::Iterator //////////
NetAddressList::Iterator::Iterator(NetAddressList const& addressList)
  : fAddressList(addressList), fNextIndex(0) {}

NetAddress const* NetAddressList::Iterator::nextAddress() {
  if (fNextIndex >= fAddressList.numAddresses()) return NULL; // no more
  return fAddressList.fAddressArray[fNextIndex++];
}


////////// Port //////////

Port::Port(portNumBits num /* in host byte order */) {
  fPortNum = htons(num);
}

UsageEnvironment& operator<<(UsageEnvironment& s, const Port& p) {
  return s << ntohs(p.num());
}


////////// AddressPortLookupTable //////////

AddressPortLookupTable::AddressPortLookupTable()
  : fTable(HashTable::create(4+4+1)) { // ip=4*4 max, port is 16 bits (<32 = '1')
}

AddressPortLookupTable::~AddressPortLookupTable() {
  delete fTable;
}

void* AddressPortLookupTable::Add(NetAddress address1,
				  NetAddress address2,
				  Port port, void* value) {
std::cerr << "AddressPortLookupTable::Add port=" << port.port() << " -value=" << value << "\n";
  uint8_t key[9*4] = {};
  this->buildKey( address1, address2, port, key );
  return fTable->Add((char*)key, value);
}

void AddressPortLookupTable::buildKey(NetAddress address1,
                                     NetAddress address2,
                                     Port port, uint8_t * key ) const {
  memcpy( key, address1.data(), address1.length() );
  memcpy( key+16, address2.data(), address2.length() );
  key[32] = (uint8_t)((port.num() >> 8) & 0xff);
  key[33] = (uint8_t)(port.num() & 0xff);
}

void* AddressPortLookupTable::Lookup(NetAddress address1,
				     NetAddress address2,
				     Port port) {
  uint8_t key[9*4] = {};
  this->buildKey( address1, address2, port, key );
  void * ret = fTable->Lookup((char*)key);
std::cerr << "AddressPortLookupTable::Lookup port=" << port.port() << " -ret=" << ret << "\n";
  return ret;
}

Boolean AddressPortLookupTable::Remove(NetAddress address1,
				       NetAddress address2,
				       Port port) {
std::cerr << "AddressPortLookupTable::Remove() port=" << port.port() << "\n";
  uint8_t key[9*4] = {};
  this->buildKey( address1, address2, port, key );
  return fTable->Remove((char*)key);
}

AddressPortLookupTable::Iterator::Iterator(AddressPortLookupTable& table)
  : fIter(HashTable::Iterator::create(*(table.fTable))) {
}

AddressPortLookupTable::Iterator::~Iterator() {
  delete fIter;
}

void* AddressPortLookupTable::Iterator::next() {
  char const* key; // dummy
  return fIter->next(key);
}

////////// Misc. //////////

Boolean IsMulticastAddress(NetAddress address) {
  return address.isMulticast();
}

struct sockaddr_storage makeSockAddr( NetAddress address, Port port, socklen_t * len ) {
  struct sockaddr_storage addr = address.makeSockAddr( port, len );
  return addr;
}

NetAddress getSockNameFromSocket(int clientSocket) {
  struct sockaddr_storage addr;
  socklen_t namelen = sizeof(addr);
  getsockname(clientSocket, (struct sockaddr*)&addr, &namelen);
  return NetAddress( (struct sockaddr*)&addr, namelen );
}



